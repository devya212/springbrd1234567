package com.nucleus.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.nucleus.model.Customer;
@Repository
//insert into customer0101(customer_code,customer_name,cust_address1,cust_address2,pin,email,contactno,contact_person,record_status,flag,create_date,created_by) values(?,?,?,?,?,?,?,?,?,?,?,?)
public class CustomerRDBMSDaoImpl implements ICustomerDao  {

	@Autowired
	JdbcTemplate jdbctemplate;
	@Override
	public boolean insert(Customer customer) {
		
		Object obj[]={customer.getCustomerCode(),customer.getCustomerName(),customer.getCustomerAddress1(),customer.getCustomerAddress2(),customer.getCustomerPinCode(),customer.getEmail(),customer.getContactNo(),customer.getPrimaryContactPerson(),customer.getRecordStatus(),customer.getFlag(),new java.sql.Date(customer.getCreateDate().getTime()),customer.getCreatedBy()};
		jdbctemplate.update("insert into customer0101(customer_code,customer_name,cust_address1,cust_address2,pin,email,contactno,contact_person,record_status,flag,create_date,created_by) values(?,?,?,?,?,?,?,?,?,?,?,?)",obj);
	   return true;
	}

	@Override
	public boolean delete(Customer customer) {
		Object obj[]={customer.getCustomerCode()};
		jdbctemplate.update("delete from customer0101 where customer_code=?",obj);
	   return true;
	}

	@Override
	public boolean update(Customer customer, String customerCode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		Customer customer1=jdbctemplate.query("select * from customer0101 where customer_code='"+customer.getCustomerCode()+"'",new ResultSetExtractor<Customer>()
				{

					@Override
					public Customer extractData(ResultSet rs) throws SQLException, DataAccessException {
						if(rs.next())
						{
							Customer customer=new Customer();
							
							customer.setCustomerCode(rs.getString(1));
							customer.setCustomerName(rs.getString(2));
							customer.setCustomerAddress1(rs.getString(3));
							customer.setCustomerAddress2(rs.getString(4));
							customer.setCustomerPinCode(String.valueOf(rs.getInt(5)));
							customer.setEmail(rs.getString(6));
							customer.setContactNo(String.valueOf(rs.getLong(7)));
							customer.setPrimaryContactPerson(rs.getString(8));
							customer.setRecordStatus(rs.getString(9));
							customer.setFlag(rs.getString(10));
							customer.setCreateDate(rs.getDate(11));
							customer.setCreatedBy(rs.getString(12));
							customer.setModifiedDate(rs.getDate(13));
							customer.setModifiedBy(rs.getString(14));
							customer.setAuthorizedDate(rs.getDate(15));
							customer.setAuthorizedBy(rs.getString(16));
							return customer;
						}
						return null;
					}
			
				});
		return customer1;
				}

}