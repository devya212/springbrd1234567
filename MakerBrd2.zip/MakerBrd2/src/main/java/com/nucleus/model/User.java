package com.nucleus.model;

public class User {

}
