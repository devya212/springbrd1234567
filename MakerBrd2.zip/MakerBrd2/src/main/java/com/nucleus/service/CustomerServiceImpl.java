package com.nucleus.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nucleus.dao.CustomerRDBMSDaoImpl;
import com.nucleus.dao.ICustomerDao;
import com.nucleus.model.Customer;
@Service
public class CustomerServiceImpl implements ICustomerService {
	@Autowired
	ICustomerDao icdao;
	boolean check;
	List<Customer> list;
	Customer customer;
	public boolean insert(Customer customer)
	{
		check=icdao.insert(customer);
		return check;
		
	}
	
	public boolean update(Customer customer,String customerCode)
	{
	       check=icdao.update(customer,customerCode);
		return check;
		
	}
	@Override
	public boolean delete(Customer customer) {
		check=icdao.delete(customer);
		return check;
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		customer=icdao.updateCustomer(customer);
		return customer;
	}
	
		
}